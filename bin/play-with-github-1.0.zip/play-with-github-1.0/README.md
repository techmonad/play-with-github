play-with-github - Cumulative reports view of Github Repository
-------------------------------------------------------------------


* Clone the project into local system
* To run the Play framework 2.5.x, you need JDK 8
* Install Typesafe Activator if you do not have it already. You can get it from here: [download](http://www.playframework.com/download)
* Execute `activator clean compile` to build the product
* Execute `activator run` to execute the product
* [play-with-github](#) should now be accessible at [localhost:9000](http://localhost:9000/)
